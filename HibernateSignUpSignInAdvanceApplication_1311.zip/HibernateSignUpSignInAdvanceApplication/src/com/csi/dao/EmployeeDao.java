package com.csi.dao;

import com.csi.model.Employee;

public interface EmployeeDao {

	public void empSignUp(Employee employee);
	
	public boolean empSignIn(String empEmailId, String empPassword);
}
