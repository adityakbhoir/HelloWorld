package com.csi.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.csi.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	private static SessionFactory factory = new AnnotationConfiguration().configure().buildSessionFactory();

	@Override
	public void empSignUp(Employee employee) {
		// TODO Auto-generated method stub

		Session session = factory.openSession();

		Transaction transaction = session.beginTransaction();

		session.save(employee);
		transaction.commit();
	}

	@Override
	public boolean empSignIn(String empEmailId, String empPassword) {
		// TODO Auto-generated method stub

		boolean status = false;
		Session session = factory.openSession();
		List<Employee> empList = session.createQuery("from Employee").list();

		for (Employee e : empList) {
			if (e.getEmpEmailId().equals(empEmailId) && e.getEmpPassword().equals(empPassword)) {
				status = true;
			}
		}

		return status;
	}

}
