package com.csi.service;

import com.csi.dao.EmployeeDao;
import com.csi.dao.EmployeeDaoImpl;
import com.csi.model.Employee;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao employeeDaoImpl = new EmployeeDaoImpl();
	
	@Override
	public void empSignUp(Employee employee) {
		// TODO Auto-generated method stub
		employeeDaoImpl.empSignUp(employee);
	}

	@Override
	public boolean empSignIn(String empEmailId, String empPassword) {
		// TODO Auto-generated method stub
		return employeeDaoImpl.empSignIn(empEmailId, empPassword);
	}

}
