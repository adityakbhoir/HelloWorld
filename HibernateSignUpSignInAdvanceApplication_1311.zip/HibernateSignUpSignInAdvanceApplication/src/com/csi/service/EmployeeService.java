package com.csi.service;

import com.csi.model.Employee;

public interface EmployeeService {
	public void empSignUp(Employee employee);

	public boolean empSignIn(String empEmailId, String empPassword);
}
